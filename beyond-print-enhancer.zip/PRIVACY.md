# Privacy Policy

The _D&DBeyond Print Enhancer_ browser extension strictly does one thing: Improves D&D Beyond's character sheet printing. Not one thing else.

This means that:
- It collects no user or usage data.
- Makes no requests to any external site service.
- Does not read or modify any part of any site besides what is needed on D&D Beyond.
